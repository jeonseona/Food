import pygame
import random
import sys

# 초기화
pygame.init()

# 화면 크기 설정
screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))

# 색상 정의
black = (0, 0, 0)
white = (255, 255, 255)
red = (255, 0, 0)

# 게임 이름 설정
pygame.display.set_caption("총 쏘기 게임")

# 이미지 로드 및 크기 조정 함수
def load_image(path, size):
    image = pygame.image.load(path).convert_alpha()
    image = pygame.transform.scale(image, size)
    return image

# 둥근 이미지 만들기
def make_rounded_image(image, radius):
    mask = pygame.Surface((image.get_width(), image.get_height()), pygame.SRCALPHA)
    pygame.draw.circle(mask, (255, 255, 255, 255), (image.get_width() // 2, image.get_height() // 2), radius)
    mask.blit(image, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
    return mask

# 이미지 로드 및 크기 조정
player_image = make_rounded_image(load_image('player.png', (50, 50)), 25)
enemy_image = make_rounded_image(load_image('enemy.png', (50, 50)), 25)
bullet_image = load_image('bullet.png', (10, 20))  # 총알은 둥글지 않음
item_image = make_rounded_image(load_image('item.png', (30, 30)), 15)

# 플레이어 설정
player_width = player_image.get_width()
player_height = player_image.get_height()
player_x = screen_width // 2
player_y = screen_height // 2
player_speed = 15

# 적 설정
enemy_width = enemy_image.get_width()
enemy_height = enemy_image.get_height()
enemy_speed = 5
enemy_list = []

# 총알 설정
bullet_width = bullet_image.get_width()
bullet_height = bullet_image.get_height()
bullet_speed = 10
bullet_list = []

# 아이템 설정
item_width = item_image.get_width()
item_height = item_image.get_height()
item_list = []
item_speed = 3
item_spawn_time = 5000  # 5초마다 아이템 생성
last_item_spawn_time = pygame.time.get_ticks()

# 시계 설정
clock = pygame.time.Clock()

# 점수 초기화
score = 0

# 폰트 설정
font = pygame.font.SysFont(None, 55)
small_font = pygame.font.SysFont(None, 35)

# 점수 표시 함수
def show_score(x, y):
    score_text = font.render("Score: " + str(score), True, white)
    screen.blit(score_text, (x, y))

# 게임 오버 메시지 표시 함수
def show_game_over():
    game_over_text = font.render("Game Over", True, red)
    screen.blit(game_over_text, (screen_width // 2 - game_over_text.get_width() // 2, screen_height // 2 - 50))

    restart_text = small_font.render("Click to restart", True, white)
    screen.blit(restart_text, (screen_width // 2 - restart_text.get_width() // 2, screen_height // 2 + 20))

# 게임 재시작 함수
def restart_game():
    global score, player_x, player_y, bullet_list, enemy_list, item_list, bullet_speed
    score = 0
    player_x = screen_width // 2
    player_y = screen_height // 2
    bullet_list = []
    enemy_list = []
    item_list = []
    bullet_speed = 10

# 버튼 영역 체크 함수
def is_mouse_over_button(button_rect):
    mouse_x, mouse_y = pygame.mouse.get_pos()
    return button_rect.collidepoint(mouse_x, mouse_y)

# 메인 게임 루프
game_running = True
game_over = False
while game_running:
    screen.fill(black)
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            game_running = False
        elif event.type == pygame.MOUSEBUTTONDOWN and game_over:
            if is_mouse_over_button(restart_button_rect):
                restart_game()
                game_over = False

    if not game_over:
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and player_x > 0:
            player_x -= player_speed
        if keys[pygame.K_RIGHT] and player_x < screen_width - player_width:
            player_x += player_speed
        if keys[pygame.K_UP] and player_y > 0:
            player_y -= player_speed
        if keys[pygame.K_DOWN] and player_y < screen_height - player_height:
            player_y += player_speed
        if keys[pygame.K_SPACE]:
            bullet_list.append([player_x + player_width // 2 - bullet_width // 2, player_y])

        # 적 생성
        if random.randint(1, 20) == 1:
            enemy_list.append([random.randint(0, screen_width - enemy_width), -enemy_height])

        # 적 이동
        for enemy in enemy_list:
            enemy[1] += enemy_speed
            if enemy[1] > screen_height:
                enemy_list.remove(enemy)
                score -= 1  # 점수 감소

            # 플레이어와 적 충돌 체크
            if (player_x < enemy[0] + enemy_width and player_x + player_width > enemy[0] and
                player_y < enemy[1] + enemy_height and player_y + player_height > enemy[1]):
                game_over = True

        # 총알 이동
        for bullet in bullet_list:
            bullet[1] -= bullet_speed
            if bullet[1] < 0:
                bullet_list.remove(bullet)

        # 충돌 체크
        for enemy in enemy_list:
            for bullet in bullet_list:
                if (bullet[0] > enemy[0] and bullet[0] < enemy[0] + enemy_width) and \
                   (bullet[1] > enemy[1] and bullet[1] < enemy[1] + enemy_height):
                    enemy_list.remove(enemy)
                    bullet_list.remove(bullet)
                    score += 1
                    break

        # 아이템 생성
        current_time = pygame.time.get_ticks()
        if current_time - last_item_spawn_time > item_spawn_time:
            item_list.append([random.randint(0, screen_width - item_width), -item_height])
            last_item_spawn_time = current_time

        # 아이템 이동
        for item in item_list:
            item[1] += item_speed
            if item[1] > screen_height:
                item_list.remove(item)

        # 아이템 충돌 체크
        for item in item_list:
            if (player_x < item[0] < player_x + player_width or player_x < item[0] + item_width < player_x + player_width) and \
               (player_y < item[1] < player_y + player_height or player_y < item[1] + item_height < player_y + player_height):
                item_list.remove(item)
                bullet_speed += 2  # 총알 속도 업그레이드

        # 플레이어 그리기
        screen.blit(player_image, (player_x, player_y))

        # 적 그리기
        for enemy in enemy_list:
            screen.blit(enemy_image, (enemy[0], enemy[1]))

        # 총알 그리기
        for bullet in bullet_list:
            screen.blit(bullet_image, (bullet[0], bullet[1]))

        # 아이템 그리기
        for item in item_list:
            screen.blit(item_image, (item[0], item[1]))

        # 점수 표시
        show_score(10, 10)

    else:
        show_game_over()

        # 재시작 버튼 그리기
        restart_button_rect = pygame.Rect(screen_width // 2 - 100, screen_height // 2 + 50, 200, 50)
        pygame.draw.rect(screen, white, restart_button_rect)
        restart_text = small_font.render("Restart", True, black)
        screen.blit(restart_text, (restart_button_rect.centerx - restart_text.get_width() // 2, restart_button_rect.centery - restart_text.get_height() // 2))

        # 마우스가 버튼 위에 있으면 색상 변경
        if is_mouse_over_button(restart_button_rect):
            pygame.draw.rect(screen, (150, 150, 150), restart_button_rect)

    pygame.display.flip()
    clock.tick(30)

pygame.quit()
