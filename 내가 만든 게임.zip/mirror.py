import pygame
import sys

# 초기화
pygame.init()

# 화면 설정
screen_width = 600
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("간단한 미로 탈출 게임")

# 색상 정의
black = (0, 0, 0)
white = (255, 255, 255)
blue = (0, 0, 255)

# 캐릭터 설정
player_size = 30
player_color = blue
player_x = 30
player_y = 30
player_speed = 5

# 출구 설정
exit_size = 30
exit_color = (255, 0, 0)
exit_x = screen_width - exit_size - 30
exit_y = screen_height - exit_size - 30

# 미로 생성 (간단한 예제로 하드코딩)
maze = [
    [1, 1, 1, 0, 1, 1, 1, 1, 1],
    [1, 0, 1, 0, 1, 0, 0, 0, 1],
    [1, 0, 1, 0, 1, 0, 1, 0, 1],
    [1, 0, 1, 0, 1, 0, 1, 0, 1],
    [1, 0, 0, 0, 1, 0, 1, 0, 1],
    [1, 1, 1, 0, 1, 0, 1, 0, 1],
    [1, 0, 0, 0, 0, 0, 1, 0, 0],
    [1, 1, 1, 1, 1, 1, 1, 1, 1]
]

# 게임 루프
running = True
while running:
    # 화면 클리어
    screen.fill(black)
    
    # 이벤트 처리
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            pygame.quit()
            sys.exit()

    # 키보드 입력 처리
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        if player_x > 0 and maze[int((player_y + player_size / 2) // 60)][int((player_x - player_speed) // 60)] == 0:
            player_x -= player_speed
    if keys[pygame.K_RIGHT]:
        if player_x < screen_width - player_size and maze[int((player_y + player_size / 2) // 60)][int((player_x + player_speed + player_size) // 60)] == 0:
            player_x += player_speed
    if keys[pygame.K_UP]:
        if player_y > 0 and maze[int((player_y - player_speed) // 60)][int((player_x + player_size / 2) // 60)] == 0:
            player_y -= player_speed
    if keys[pygame.K_DOWN]:
        if player_y < screen_height - player_size and maze[int((player_y + player_speed + player_size) // 60)][int((player_x + player_size / 2) // 60)] == 0:
            player_y += player_speed

    # 출구와 충돌 체크
    if player_x < exit_x + exit_size and player_x + player_size > exit_x and player_y < exit_y + exit_size and player_y + player_size > exit_y:
        # 출구에 도달하면 게임 종료
        running = False

    # 캐릭터 그리기
    pygame.draw.rect(screen, player_color, pygame.Rect(player_x, player_y, player_size, player_size))

    # 출구 그리기
    pygame.draw.rect(screen, exit_color, pygame.Rect(exit_x, exit_y, exit_size, exit_size))

    # 미로 그리기
    for row in range(len(maze)):
        for col in range(len(maze[0])):
            if maze[row][col] == 1:
                pygame.draw.rect(screen, white, pygame.Rect(col * 60, row * 60, 60, 60))

    pygame.display.flip()

# 게임 종료
pygame.quit()
sys.exit()
