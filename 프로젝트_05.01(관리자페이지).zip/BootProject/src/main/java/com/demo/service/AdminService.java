package com.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.demo.domain.AdminBoard;
import com.demo.domain.Member;

public interface AdminService {
	
	// 관리자인지 체크(id 및 유저코드)
	int adminCheck(Member vo);
	
	// 관리자인 경우 모든 멤버의 정보조회
	public List<Member> getAllMemberList();
	
	// 관리자인 경우 모든 음식게시판 정보조회
	public List<AdminBoard> getAllFoodBoardList();
	
	// 관리자인 경우 모든 Q&A게시판 정보조회
	public List<AdminBoard> getAllQnaBoardList();
		
	// 관리자인 경우 모든 1:1문의게시판 정보조회
	public List<AdminBoard> getAllAskBoardList();
	
	// 게시글 저장
	public void insertAdminBoard(AdminBoard vo);
	
	// 게시글 수정
	public void updateAdminBoard(AdminBoard vo);
	
	// 게시글 삭제
	public void deleteAdminBoard(AdminBoard vo);
}
