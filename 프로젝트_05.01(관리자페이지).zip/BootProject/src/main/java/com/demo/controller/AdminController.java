package com.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.SessionAttribute;

import com.demo.domain.AdminBoard;
import com.demo.domain.Member;
import com.demo.service.AdminService;

@Controller
public class AdminController {
	
	@Autowired
	AdminService adminService;
	
	@GetMapping("/main.do")
	public String mainView(Model model) {
		List<AdminBoard> askBoardList = adminService.getAllAskBoardList();
		model.addAttribute("askBoardList", askBoardList);
		return "admin/admin_main";
	}
	
	// 회원 관리 페이지를 누르면 회원 정보 전체 조회
	@GetMapping("/memberList.do")
	public String memberInfo(Member vo, Model model) {
		adminService.adminCheck(vo);
		List<Member> memberList = adminService.getAllMemberList();
		model.addAttribute("memberList", memberList);
		
		return "admin/admin_userlist";  // 회원 정보 페이지로 이동
	}
	
	// 관리자 음식레시피 게시판
	@GetMapping("/admin_food.do")
	public String foodBoard(Member vo, Model model) {
		adminService.adminCheck(vo);
		List<AdminBoard> foodBoardList = adminService.getAllFoodBoardList();
		model.addAttribute("foodBoardList", foodBoardList);
		
		return "admin/admin_foodboard";  // 관리자 음식레시피 게시판으로 이동
	}
	
	// 관리자 Q&A 게시판
	@GetMapping("/admin_QnA.do")
	public String QnABoard(Member vo, Model model) {
		adminService.adminCheck(vo);
		List<AdminBoard> qnaBoardList= adminService.getAllQnaBoardList();
		model.addAttribute("qnaBoardList", qnaBoardList);
			
		return "admin/admin_qnaboard";  // 관리자 Q&A 게시판으로 이동
	}
		
	// 관리자 1:1문의 게시판
	@GetMapping("/admin_ask.do")
	public String AskBoard(Member vo, Model model) {
		adminService.adminCheck(vo);
		List<AdminBoard> askBoardList = adminService.getAllAskBoardList();
		model.addAttribute("askBoardList", askBoardList);
			
		return "admin/admin_askboard";  // 관리자 1:1문의 게시판으로 이동
	}
	
	@GetMapping("/qnaRegister.do")
	public String qnaRegiView() {
		
		return "admin/qnaFoam";
	}
	
	@PostMapping("/qnaReg.do")
	public void qnaRegister(AdminBoard vo) {
		// 로그인 정보를 Member타입으로 받아와서 vo객체에 비어있는 정보에 insert해야함
		// 로그인 영역에서 처리하는 방식대로 개선
		adminService.insertAdminBoard(vo);
	}
	
}
