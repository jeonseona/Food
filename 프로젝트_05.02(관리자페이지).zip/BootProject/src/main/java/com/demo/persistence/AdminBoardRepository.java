package com.demo.persistence;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.demo.domain.AdminBoard;
import com.demo.domain.Member;

public interface AdminBoardRepository extends JpaRepository<AdminBoard, Integer> {

	@Query(value="SELECT * FROM member", nativeQuery = true)
	List<Member> getAllMember();
	
	@Query(value="SELECT * FROM admin_board WHERE boardcode = :codeNum", nativeQuery = true)
	List<AdminBoard >findByBoardCode(int codeNum);
	
	@Query(value="SELECT * FROM admin_board WHERE boardnum = :boardnum", nativeQuery = true)
	AdminBoard findByBoardnum(int boardnum);
}
