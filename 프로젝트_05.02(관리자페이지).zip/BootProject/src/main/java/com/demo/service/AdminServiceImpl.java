package com.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.domain.AdminBoard;
import com.demo.domain.Member;
import com.demo.persistence.AdminBoardRepository;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	private AdminBoardRepository adminBoardRepo;

	@Override
	public int adminCheck(Member vo) {
		int result = -1;
//		
//		// Member 테이블에서 사용자 조회
//		Optional<Member> mmber = memberRepo.findById(vo.getId());
//		
//		// 결과값 설정 (1:ID, PWD 일치 / 0: PWD 불일치 / -1: ID가 존재하지 않음)
//		// 멤버 전체에 대하여 사용자 객체의 id를 조회하고
//		// id가 존재할경우 해당 id의 유저코드를 가져와서 관리자(1)인 경우 1을 반환
//		if(member.isEmpty()) {
//			result = -1;
//		} else {
//			if(member.get().getUsercode().equals(1)) {
//				return result = 1;
//			} else {
//				return result = -1;
//			}
//		}
		return result;
	}

	@Override
	public List<Member> getAllMemberList() {
		// TODO Auto-generated method stub
		return adminBoardRepo.getAllMember();
	}

	@Override
	public void insertAdminBoard(AdminBoard vo) {
		adminBoardRepo.save(vo);
		
	}

	@Override
	public void updateAdminBoard(AdminBoard vo) {
		AdminBoard board = adminBoardRepo.findById(vo.getBoardnum()).get();
		
		vo.setRegdate(board.getRegdate());
		adminBoardRepo.save(vo);
	}


	@Override
	public void deleteAdminBoard(int boardnum) {
		adminBoardRepo.deleteById(boardnum);
		
	}

	@Override
	public List<AdminBoard> getAllFoodBoardList() {
		return adminBoardRepo.findByBoardCode(1);
	}

	@Override
	public List<AdminBoard> getAllQnaBoardList() {
		// TODO Auto-generated method stub
		return adminBoardRepo.findByBoardCode(2);
	}

	@Override
	public List<AdminBoard> getAllAskBoardList() {
		// TODO Auto-generated method stub
		return adminBoardRepo.findByBoardCode(3);
	}

	@Override
	public AdminBoard getByBoardnum(int boardnum) {
		// TODO Auto-generated method stub
		return adminBoardRepo.findByBoardnum(boardnum);
	}

}
