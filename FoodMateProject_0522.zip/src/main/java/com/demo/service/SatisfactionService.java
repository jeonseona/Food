package com.demo.service;

import com.demo.dto.SatisfactionDTO;

public interface SatisfactionService {
    void saveSatisfaction(SatisfactionDTO satisfactionDTO);
}
