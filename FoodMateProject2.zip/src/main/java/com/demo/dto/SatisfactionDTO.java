package com.demo.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SatisfactionDTO {
	private String rating;

	public String getRating() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getSatisfaction() {
		// TODO Auto-generated method stub
		return null;
	}

    // getters and setters
}