package com.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class NaverLoginController {

    @GetMapping("/naver/callback")
    public String handleNaverCallback(Model model, @RequestParam("email") String email, @RequestParam("nickname") String nickname, @RequestParam("age") int age) {
        // 받아온 사용자 정보를 처리하는 로직을 작성
        // 예를 들어, 받아온 정보를 모델에 담아서 뷰로 전달하거나, 데이터베이스에 저장할 수 있음
        model.addAttribute("email", email);
        model.addAttribute("nickname", nickname);
        model.addAttribute("age", age);
        return "naver_callback"; // 사용자 정보를 보여주는 페이지로 이동
    }
}
