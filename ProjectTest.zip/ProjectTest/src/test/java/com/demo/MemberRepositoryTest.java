package com.demo;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.demo.domain.Member;
import com.demo.dto.MemberData;
import com.demo.persistence.MemberDataRepository;
import com.demo.persistence.MemberRepository;

@SpringBootTest
public class MemberRepositoryTest {
	@Autowired
	private MemberRepository memberRepo;
	@Autowired
	private MemberDataRepository mdRepo;
	
	@Disabled
	@Test
	public void insertMember() {
		Member test = Member.builder()
				.id("test")
				.usercode(0)
				.pwd("test")
				.name("test")
				.email("test@email.com")
				.nickname("test")
				.build();
		memberRepo.save(test);
		
		MemberData memberData = new MemberData();
		memberData.setMember(test);
		memberData.setAge(0);  // 초기값 설정, 사용자에게 입력받은 값이 있다면 설정
        memberData.setHeight(0);  // 초기값 설정
        memberData.setWeight(0);  // 초기값 설정
        memberData.setGender("정보없음");  // 초기값 설정
        memberData.setBmi(0.0);  // 초기값 설정
        memberData.setGoal("정보없음");  // 초기값 설정
        memberData.setCode("Default");  // 초기값 설정
		mdRepo.save(memberData);
	}
}
