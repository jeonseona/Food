package com.demo.service;

import com.demo.domain.MemberData;

public interface MemberDataService {

	// 마이페이지
	// 개인정보 수정
	public void changeInfo(MemberData vo);
}
