package com.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.domain.MemberData;
import com.demo.persistence.MemberDataRepository;

@Service
public class MemberDataServiceImpl implements MemberDataService {

	@Autowired
	private MemberDataRepository MemberDataRepo;

	@Override
	public void changeInfo(MemberData vo) {
		// 
		MemberDataRepo.updateMemberData(vo.getId(), vo.getHeight(), vo.getWeight(),
				vo.getBmi(), vo.getAge(), vo.getGender(), vo.getGoal());
		

	}


}
